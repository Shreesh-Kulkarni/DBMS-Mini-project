# COVID19-Hospital-Management-System-
Django project

Covid19 hospital management system is a web application for a mini project in DBMS. 

-->front end : Django

-->Back end : Oracle db

-->programming language : Python
