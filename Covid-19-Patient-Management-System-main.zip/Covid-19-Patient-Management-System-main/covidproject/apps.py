from django.apps import AppConfig


class CovidProjectConfig(AppConfig):
    name = 'covidproject'
