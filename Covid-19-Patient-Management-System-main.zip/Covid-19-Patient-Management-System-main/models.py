Operations to perform:
  Apply all migrations: admin, auth, contenttypes, covidproject, sessions
Running migrations:
